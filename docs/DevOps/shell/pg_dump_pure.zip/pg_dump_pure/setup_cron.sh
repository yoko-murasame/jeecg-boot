#!/bin/bash

BACKUP_DIR=/root/pgbackup
SCRIPT_Name=pgbackup-gongye-db.sh
chmod +x ${BACKUP_DIR}/pg_dump
chmod +x ${BACKUP_DIR}/libpq.so
chmod +x ${BACKUP_DIR}/libpq.so.5
chmod +x ${BACKUP_DIR}/${SCRIPT_Name}

#定时同步任务使用本地pg_dump文件需添加环境变量
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${BACKUP_DIR}
# Check if LD_LIBRARY_PATH is already set
if [[ -z "${LD_LIBRARY_PATH}" ]]; then
    export LD_LIBRARY_PATH=${BACKUP_DIR}
else
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${BACKUP_DIR}
fi
${BACKUP_DIR}/${SCRIPT_Name}

# Write out current crontab
crontab -l > mycron

# Check if job already exists
job="0 0 * * * ${BACKUP_DIR}/${SCRIPT_Name}"
grep -q "$job" mycron || echo "$job" >> mycron

# Install new cron file
crontab mycron
rm mycron
echo "Script executed successfully!"
